module XmlHelper
end
